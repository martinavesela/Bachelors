import React from "react";
import {Col, Container, Row} from "react-bootstrap";
import {NavigationSK} from "./NavigationSK";

export const DiaryPage: React.FC = () => {
    return (
        <>
            <NavigationSK/>
            <div className="container-parent">
                <Container className="container-fluid main-text pt-5 pb-5" fluid="lg">
                    <h2 className="text-center text-white">Denník</h2> <br/>
                    <Row>
                        <Col className="column-left">
                            Týždeň 16.2. - 22.2.
                        </Col>
                        <Col className="column-right">
                            • pridanie denníka na stránku <br/>
                            • zmena poradia linkov v navigácii <br/>
                            • písanie východiskovej kapitoly, hlavne existujúcich riešení
                        </Col>
                    </Row>
                    <Row>
                        <Col className="column-left">
                            Týždeň 23.2. - 1.3.
                        </Col>
                        <Col className="column-right">
                            • písanie východiskovej kapitoly, konkrétne potrebnej teórie a použitých technológií
                        </Col>
                    </Row>
                    <Row>
                        <Col className="column-left">
                            Týždeň 2.3. - 8.3.
                        </Col>
                        <Col className="column-right">
                            • písanie východiskovej kapitoly, hlavne použitých technológií
                        </Col>
                    </Row>
                </Container>
            </div>
        </>
    )
};