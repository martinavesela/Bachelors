import React from "react";
import {Nav, Navbar} from "react-bootstrap";
import {Link} from "react-router-dom";

export const NavigationEN: React.FC = () => {
    return (
        <Navbar className="nav align-items-start flex-column" sticky="top">
            <Nav className="nav-item">
                <Link to="/" className="nav-row-1">Web applicaiton for learning a programming language using another
                    programming language</Link>
            </Nav>
            <Nav className="nav-item">
                <Link to="/" className="nav-row-2">Home</Link>
                <Link to="/app" className="nav-row-2">App</Link>
                <Link to="/resources" className="nav-row-2">Resources</Link>
                <Link to="/time" className="nav-row-2">Time plan</Link>
                <Link to="/diary" className="nav-row-2">Diary</Link>
            </Nav>
        </Navbar>
    );
}