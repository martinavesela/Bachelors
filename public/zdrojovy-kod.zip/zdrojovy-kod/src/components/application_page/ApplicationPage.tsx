import React from "react";
import {Col, Container, Row} from "react-bootstrap";
import {NavigationEN} from "../NavigationEN";
import {ApplicationTasks} from "./ApplicationTasks";
import {PythonApp} from "./PythonApp";
import {JavaApp} from "./JavaApp";

export const ApplicationPage: React.FC = () => {
    return (
        <>
            <NavigationEN/>
            <div className="container-parent height-100-percent">
                <Container className="container-fluid height-100-percent pt-3 pb-3" fluid>
                    <Row className="height-100-percent">
                        <Col className="height-100-percent" lg={4}>
                            <ApplicationTasks/>
                        </Col>
                        <Col className="height-100-percent" lg={4}>
                            <PythonApp/>
                        </Col>
                        <Col className="height-100-percent" lg={4}>
                            <JavaApp/>
                        </Col>
                    </Row>
                </Container>
            </div>
        </>

    )
}