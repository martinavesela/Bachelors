import React, {useRef, useState} from "react";
import CodeMirror from "@uiw/react-codemirror";
import "codemirror/keymap/sublime";
import "codemirror/theme/darcula.css";
import 'codemirror/addon/display/autorefresh';
import 'codemirror/addon/comment/comment';
import 'codemirror/addon/edit/matchbrackets';
import {Button} from "react-bootstrap";

const ResizableBox = require("react-resizable").ResizableBox;

const codePython = `print("Hello World!")
`;

const codeTestPython = `import unittest

class Test(unittest.TestCase):
  def testGood(self):
    self.assertEqual(0, 0)
  def testBad(self):
    self.assertEqual(0, 1)
    
if __name__ == '__main__':
  unittest.main()
`

export const PythonApp: React.FC = () => {
    const [isRunningPython, setRunningPython] = useState(false);
    const [isTestingPython, setTestingPython] = useState(false);
    let pythonIn = useRef<CodeMirror>(null);
    let pythonTest = useRef<CodeMirror>(null);
    let pythonOut = useRef<CodeMirror>(null);
    const runPython = () => {
        setRunningPython(true)
        window.fetch("/run/python/", {
            method: "POST",
            headers: {"Content-Type": "text/plain"},
            body: pythonIn.current?.editor.getValue()
        }).then(a => {
            return a.text()
        }).then(text => {
            pythonOut.current?.editor.setValue(text)
            setRunningPython(false)
        })
    };
    const testPython = () => {
        setTestingPython(true)
        window.fetch("/test/python/", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                pythonIn: pythonIn.current?.editor.getValue(),
                pythonTest: pythonTest.current?.editor.getValue()
            })
        }).then(a => {
            return a.text()
        }).then(text => {
            pythonOut.current?.editor.setValue(text)
            setTestingPython(false)
        })
    };
    return (
        <>
            <div className="buttons">
                <h6>Python:</h6>
                <Button className="button button-green" size="sm" disabled={isRunningPython || isTestingPython} onClick={runPython}>
                    {isRunningPython ? "Running..." : "Run"}
                </Button>
                <Button className="button button-green" size="sm" disabled={isRunningPython || isTestingPython} onClick={testPython}>
                    {isTestingPython ? "Testing..." : "Test"}
                </Button>
                {/*<Button className="button button-orange" size="sm" disabled={isRunningPython} onClick={runPython}>*/}
                {/*    {isRunningPython ? "Terminating..." : "Stop"}*/}
                {/*</Button>*/}
            </div>
            <ResizableBox className="custom-box box" width={"100%"} height={200}
                          handle={<span className="custom-handle custom-handle-se"/>}
                          minConstraints={["100%", 20]} maxConstraints={["100%", 5000]}>
                <p className="header-language">Python Input</p>
                <CodeMirror
                    ref={pythonIn}
                    value={codePython}
                    options={{
                        theme: "darcula",
                        keyMap: "sublime",
                        mode: "python",
                    }}
                />
            </ResizableBox>
            <ResizableBox className="custom-box box" width={"100%"} height={200}
                          handle={<span className="custom-handle custom-handle-se"/>}
                          minConstraints={["100%", 20]} maxConstraints={["100%", 5000]}>
                <p className="header-language">Python Tests</p>
                <CodeMirror
                    ref={pythonTest}
                    value={codeTestPython}
                    options={{
                        theme: "darcula",
                        keyMap: "sublime",
                        mode: "python",
                    }}
                />
            </ResizableBox>
            <ResizableBox className="custom-box box" width={"100%"} height={200}
                          handle={<span className="custom-handle custom-handle-se"/>}
                          minConstraints={["100%", 20]} maxConstraints={["100%", 5000]}>
                <p className="header-language">Python Output</p>
                <CodeMirror
                    ref={pythonOut}
                    value={""}
                    options={{
                        theme: "darcula",
                        keyMap: "sublime",
                        mode: "python",
                        readOnly: "true",
                    }}
                />

            </ResizableBox>
        </>
    )
}