import React from "react";
import {Button} from "react-bootstrap";

export const ApplicationTasks: React.FC = () => {
    return (
        <>
            <div className="column-app-first height-100-percent text-overflow">
                <h4 className="header-app">This page is under construction.</h4>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque id dictum
                    neque, et
                    lobortis mauris. Cras viverra eros sem, fermentum condimentum augue tristique nec.
                    Sed
                    fringilla risus nec nisl vestibulum varius. Duis pellentesque tempor quam vitae
                    aliquam.
                    Maecenas et nulla arcu. Fusce vitae elit iaculis, bibendum augue a, lobortis neque.
                    Morbi eleifend dui varius mauris finibus tempor. Fusce sed justo vitae quam
                    tincidunt
                    accumsan vitae a dui. Aliquam sit amet metus magna. Curabitur vel dapibus lorem, sit
                    amet eleifend eros.
                    Maecenas volutpat gravida diam in cursus. In ut sapien lectus. Vestibulum auctor
                    imperdiet placerat. Vestibulum ultricies risus lobortis, gravida est nec, volutpat
                    lacus. Aliquam vulputate accumsan turpis, a ultrices neque ornare vel. Nam bibendum
                    ipsum a lobortis luctus. Quisque accumsan nunc vitae lectus tempus porta eget sit
                    amet
                    felis. Quisque vehicula posuere magna, ac congue nisi pharetra at. Sed at consequat
                    dolor.
                    Curabitur eget tincidunt justo. Mauris quam nulla, pretium ut mollis in, blandit sit
                    amet urna. Duis ultricies, sapien sed tristique facilisis, dolor lacus varius
                    turpis, eu
                    mollis purus nisi eu dui. Mauris elementum dolor id nulla lobortis rutrum. Nullam
                    malesuada arcu sed fermentum venenatis. Mauris rhoncus, nisi vitae pellentesque
                    congue,
                    leo tortor efficitur velit, id ultrices eros arcu eu arcu. Donec massa massa,
                    convallis
                    ut tincidunt eget, ultricies ac nulla. Aliquam eu nisl id nulla tempor molestie.
                    Donec
                    at tortor sit amet purus ultrices venenatis a eget lorem. Mauris tincidunt vulputate
                    egestas. Suspendisse pulvinar sapien sapien, sit amet dignissim sem consequat sed.
                    Ut ac
                    eleifend nulla. Maecenas eu ex nulla. Etiam pellentesque, orci id finibus malesuada,
                    ex
                    elit blandit ante, eu suscipit nunc tellus id odio.
                    Integer eu luctus erat, quis suscipit orci. Quisque accumsan est eu massa interdum,
                    at
                    tristique nibh eleifend. Proin rhoncus orci pellentesque nisl vehicula, bibendum
                    sagittis mi commodo. Proin enim diam, semper id sagittis commodo, posuere sit amet
                    tellus. Fusce ac libero nec est porta imperdiet sit amet nec erat. Nunc tincidunt
                    consequat posuere. Nam commodo ex augue, quis interdum nisi interdum quis. Ut lectus
                    ex,
                    porta in scelerisque in, sodales ac magna. Suspendisse vel ante vitae mauris pretium
                    dignissim. Quisque ac ultricies massa. Duis ante metus, vestibulum sed nisi a,
                    accumsan
                    suscipit urna. Sed placerat fermentum molestie.
                </p>
                <div className="text-center">
                    <Button className="button button-green" size="sm">
                        Page
                    </Button>
                </div>
            </div>
        </>
    )
}