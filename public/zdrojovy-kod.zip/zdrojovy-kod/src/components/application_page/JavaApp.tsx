import React, {useRef, useState} from "react";
import CodeMirror from "@uiw/react-codemirror";
import "codemirror/keymap/sublime";
import "codemirror/theme/darcula.css";
import 'codemirror/addon/display/autorefresh';
import 'codemirror/addon/comment/comment';
import 'codemirror/addon/edit/matchbrackets';
import {Button} from "react-bootstrap";

const ResizableBox = require("react-resizable").ResizableBox;

const codeJava = `public class Main {
  public void test() {
    System.out.println("Tested.");
  }
    
  public static void main(String[] args) {
    System.out.println("Ran.");
  }
}
`;

const codeTestJava = `import static org.junit.Assert.*;

public class Test {
  @org.junit.Test
  public void testIt() {
    new Main().test();
    //assertEquals("bad test", 0, 1);
  }
}
`;

export const JavaApp: React.FC = () => {
    const [isRunningJava, setRunningJava] = useState(false);
    const [isTestingJava, setTestingJava] = useState(false);
    let javaIn = useRef<CodeMirror>(null);
    let javaTest = useRef<CodeMirror>(null);
    let javaOut = useRef<CodeMirror>(null);
    const runJava = () => {
        setRunningJava(true)
        window.fetch("/run/java/", {
            method: "POST",
            headers: {"Content-Type": "text/plain"},
            body: javaIn.current?.editor.getValue()
        }).then(a => {
            return a.text()
        }).then(text => {
            javaOut.current?.editor.setValue(text)
            setRunningJava(false)
        })
    };
    const testJava = () => {
        setTestingJava(true)
        window.fetch("/test/java/", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                javaIn: javaIn.current?.editor.getValue(),
                javaTest: javaTest.current?.editor.getValue()
            })
        }).then(a => {
            return a.text()
        }).then(text => {
            javaOut.current?.editor.setValue(text)
            setTestingJava(false)
        })
    };
    return (
        <>
            <div className="buttons">
                <h6>Java:</h6>
                <Button className="button button-green" size="sm" disabled={isRunningJava || isTestingJava} onClick={runJava}>
                    {isRunningJava ? "Running..." : "Run"}
                </Button>
                <Button className="button button-green" size="sm" disabled={isRunningJava || isTestingJava} onClick={testJava}>
                    {isTestingJava ? "Testing..." : "Test"}
                </Button>
                {/*<Button className="button button-orange" size="sm" disabled={isRunningJava} onClick={runJava}>*/}
                {/*    {isRunningJava ? "Terminating..." : "Stop"}*/}
                {/*</Button>*/}
            </div>
            <ResizableBox className="custom-box box" width={"100%"} height={200}
                          handle={<span className="custom-handle custom-handle-se"/>}
                          minConstraints={["100%", 20]} maxConstraints={["100%", 5000]}>
                <p className="header-language">Java Input</p>
                <CodeMirror
                    ref={javaIn}
                    value={codeJava}
                    options={{
                        theme: "darcula",
                        keyMap: "sublime",
                        mode: "java",
                    }}
                />
            </ResizableBox>
            <ResizableBox className="custom-box box" width={"100%"} height={200}
                          handle={<span className="custom-handle custom-handle-se"/>}
                          minConstraints={["100%", 20]} maxConstraints={["100%", 5000]}>
                <p className="header-language">Java Tests</p>
                <CodeMirror
                    ref={javaTest}
                    value={codeTestJava}
                    options={{
                        theme: "darcula",
                        keyMap: "sublime",
                        mode: "java",
                    }}
                />
            </ResizableBox>
            <ResizableBox className="custom-box box" width={"100%"} height={200}
                          handle={<span className="custom-handle custom-handle-se"/>}
                          minConstraints={["100%", 20]} maxConstraints={["100%", 5000]}>
                <p className="header-language">Java Output</p>
                <CodeMirror
                    ref={javaOut}
                    value={""}
                    options={{
                        theme: "darcula",
                        keyMap: "sublime",
                        mode: "java",
                        readOnly: "true",
                    }}
                />
            </ResizableBox>
        </>
    )
}