import os
import random
import string

import docker
from docker.types import Mount
from flask import Flask, request, Response, send_file

app = Flask(__name__)
docker_d = docker.from_env()


@app.route("/run/java/", methods=["POST"])
def run_java():
    directory = "mount/" + ("".join(random.choice(string.ascii_lowercase) for _ in range(10)))
    os.mkdir(directory)
    with open(directory + "/Main.java", "w") as f:
        data = request.get_data().decode("utf-8")
        f.write(data)
    docker_d.containers.run(
        "runjava",
        mounts=[Mount("/usr/java/mount", os.path.abspath(directory), type="bind")],
        name="runjava",
        remove=True)
    return send_file(directory + "/stdout.txt")


@app.route("/test/java/", methods=["POST"])
def test_java():
    directory = "mount/" + ("".join(random.choice(string.ascii_lowercase) for _ in range(10)))
    os.mkdir(directory)
    data = request.get_json()
    with open(directory + "/Main.java", "w") as f:
        f.write(data["javaIn"])
    with open(directory + "/Test.java", "w") as f:
        f.write(data["javaTest"])
    docker_d.containers.run(
        "testjava",
        mounts=[Mount("/usr/java/mount", os.path.abspath(directory), type="bind")],
        name="testjava",
        remove=True)
    return send_file(directory + "/stdout.txt")


@app.route("/run/python/", methods=["POST"])
def run_python():
    directory = "mount/" + ("".join(random.choice(string.ascii_lowercase) for _ in range(10)))
    os.mkdir(directory)
    with open(directory + "/main.py", "w") as f:
        data = request.get_data().decode("utf-8")
        f.write(data)
    docker_d.containers.run(
        "runpython",
        mounts=[Mount("/usr/python/mount", os.path.abspath(directory), type="bind")],
        name="runpython",
        remove=True)
    return send_file(directory + "/stdout.txt")


@app.route("/test/python/", methods=["POST"])
def test_python():
    directory = "mount/" + ("".join(random.choice(string.ascii_lowercase) for _ in range(10)))
    os.mkdir(directory)
    data = request.get_json()
    with open(directory + "/main.py", "w") as f:
        f.write(data["pythonIn"])
    with open(directory + "/test.py", "w") as f:
        f.write(data["pythonTest"])
    docker_d.containers.run(
        "testpython",
        mounts=[Mount("/usr/python/mount", os.path.abspath(directory), type="bind")],
        name="testpython",
        remove=True)

    def lines():
        with open(directory + "/stdout.txt", "r") as f:
            for line in f.readlines():
                yield line
        yield "----------------------------------------------------------------------\n"
        with open(directory + "/stderr.txt", "r") as f:
            for line in f.readlines():
                yield line

    return Response(lines(), mimetype="text/plain")


if __name__ == '__main__':
    app.run()
